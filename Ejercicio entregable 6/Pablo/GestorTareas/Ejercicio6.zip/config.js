module.exports = {
    /* Configuración de los datos de acceso a la BD */
    mysqlConfig: {
        database: "tareas",
        host: "91.121.109.58",
        user: "usuariop1",
        password: "accesop1"
    },
    
    /* Puerto de escucha */
    port: 3000
};

