"use strict";

module.exports = {
    // Puerto en es que escuchará el servidor
    port: 3000
}